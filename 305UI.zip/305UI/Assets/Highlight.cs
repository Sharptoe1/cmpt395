﻿using UnityEngine;
using System.Collections;

public class Highlight : MonoBehaviour {
	float lastHit;
	Color yellow = new Color(1,1,0);
	Color red = new Color(1,0,1);
	bool hovered;
	Rect dataview;
	GameObject viewer;
	GameObject dataviewer;
	void Start(){
		
	viewer = transform.FindChild("Miniview").gameObject;
	dataviewer = transform.FindChild("dataviewprefab").gameObject;
}
	void OnMouseOver(){
		lastHit = Time.time;
		hovered = true;
		
	}
	void OnMouseDown(){
		dataviewer.SetActive(true);
	}
	void Update(){
		float dt = Time.time-lastHit;
		renderer.material.color=Color.Lerp(yellow, red,dt);
		viewer.SetActive(dt < .5f);
		dataviewer.SetActive(false);
		}
}			
